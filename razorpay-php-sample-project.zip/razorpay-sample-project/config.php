<?php
// Razorpay API configuration

$razorpay_config = array(
    'api_key' => 'rzp_test_Y2wy8t1wD1AFaA',
    'api_secret' => 'zSqRMpIa2ljBBpkieFYGmfLa',
);

// Other configurations, if needed
?>
